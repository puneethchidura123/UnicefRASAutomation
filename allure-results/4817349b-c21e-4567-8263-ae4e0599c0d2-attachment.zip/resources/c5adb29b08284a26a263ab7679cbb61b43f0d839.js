/*!
 * SAPUI5

(c) Copyright 2009-2019 SAP SE. All rights reserved
 */
sap.ui.define([],function(){"use strict";var R=function(){throw new Error();};R.createInstance=function(c){var r=Object.create(this.prototype||null);r._oLegendControl=c;return r;};R.prototype._oLegendControl=undefined;R.prototype.show=function(){};R.prototype.hide=function(){};R.prototype.setOpenBy=function(o){};return R;},true);
