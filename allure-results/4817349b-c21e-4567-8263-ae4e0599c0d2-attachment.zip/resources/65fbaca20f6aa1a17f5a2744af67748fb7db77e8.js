/*!
 * OpenUI5
 * (c) Copyright 2009-2019 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["./Adaptation"],function(A){"use strict";var S=A.extend("sap.ui.rta.toolbar.Standalone",{renderer:'sap.ui.rta.toolbar.AdaptationRenderer',type:'standalone'});return S;},true);
