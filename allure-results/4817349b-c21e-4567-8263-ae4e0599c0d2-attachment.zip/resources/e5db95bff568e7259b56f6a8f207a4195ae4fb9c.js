/*!
 * SAPUI5

(c) Copyright 2009-2019 SAP SE. All rights reserved
 */
sap.ui.define(function(){"use strict";var F={};F.numericFormatter=function(f){return sap.viz.api.env.Format.numericFormatter.apply(null,arguments);};return F;},true);
